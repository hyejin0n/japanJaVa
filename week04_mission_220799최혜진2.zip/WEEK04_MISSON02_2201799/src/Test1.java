class A{
	int aa = 3;
	void abc() {}
}
class B extends A{
	int bb = 4;
	void bcd() {}
}
class C extends B{
	int cc = 5;
	void cde() {}
}


public class Test1 {
	public static void main(String[] args) {
		
		//A
		A a1 = new A();
		a1.abc();
		System.out.println(a1.aa);
		
		A a2 = new B();
		a2.abc();
		System.out.println(a2.aa);
		
		A a3 = new C();
		a3.abc();
		System.out.println(a3.aa);
		
		//B
		B b1 = new B();
		b1.abc();
		b1.bcd();
		System.out.println(b1.aa);
		System.out.println(b1.bb);
		
		B b2 = new C();
		b2.abc();
		b2.bcd();
		System.out.println(b2.aa);
		System.out.println(b2.bb);	
		
		//C
		C c1 = new C();
		c1.abc();
		c1.bcd();
		c1.cde();
		System.out.println(c1.aa);
		System.out.println(c1.bb);
		System.out.println(c1.cc);

	




		





		

		

		
		
	}
}
