class Friends{
	String name;
	void eat() {
		System.out.println("같이밥먹자");
	}
}
class UnivFriend extends Friends{
	int age;
	void play() {
		System.out.println("같이놀자");
	}
}
class WorkFriend extends Friends{
	int num;
	void phone() {
		System.out.println("내번호야");
	}
}

public class Test2 {
	public static void main(String[] args) {
		
		//클래스 객체 생성 ff
		Friends ff = new Friends();
		ff.name = "친구이름";
		ff.eat();
		System.out.println(ff.name);
		
		Friends ff1 = new UnivFriend();
		ff1.name = "고양이";
		ff1.eat();
		System.out.println(ff1.name);
		
		Friends ff2 = new WorkFriend();
		ff2.name = "아메리카노";
		ff2.eat();
		System.out.println(ff2.name);
				
		//클래스 객체 생성 fu
		UnivFriend fu = new UnivFriend();
		fu.name = "강지오";
		fu.age = 22;
		fu.eat();
		fu.play();

		System.out.println(fu.name);
		System.out.println(fu.age);
	
		//클래스 객체 생성 fw
		WorkFriend fw = new WorkFriend();
		fw.name = "안수영";
		fw.eat();
		fw.num = 1234;
		fw.phone();
		
		System.out.println(fw.name);
		System.out.println(fw.num);
		
		
		
		
		



		
		
		
	}
}
