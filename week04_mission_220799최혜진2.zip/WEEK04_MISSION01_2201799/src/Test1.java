class A{}
class B extends A{}
class C extends A{}
class D extends B{}
class E extends B{}
class F extends C{}


public class Test1 {
	public static void main(String[] args) {
		
		//A의 다형적 표현
		A aa = new A();
		A ab = new B();
		A ac = new C();
		A ad = new D();
		A ae = new E();
		A af = new F();
		
		//B의 다형적 표현
		B bb = new B();
		B bd = new B();
		B be = new B();
		
		//C의 다형적 표현
		C cc = new C();
		C cf = new F();
		
		//D의 다형적 표현
		D dd = new D();
		
		//E의 다형적 표현
		E ee = new E();
		
		//F의 다형적 표현
		F ff = new F();
		
	}
}
